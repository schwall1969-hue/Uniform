import './globals.css';

export const metadata = {
  title: 'Uniformlager',
  description: 'Mobile Lagerbestands-App für Uniformen',
};

export default function RootLayout({ children }) {
  return (
    <html lang="de">
      <body>{children}</body>
    </html>
  );
}
