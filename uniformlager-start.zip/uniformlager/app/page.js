'use client';

import { useMemo, useState } from 'react';

const startDaten = [
  { id: 1, geschlecht: 'Damen', produkt: 'Hemd', variation: 'LS', farbe: 'Weiß', groesse: 'S', bestand: 8 },
  { id: 2, geschlecht: 'Damen', produkt: 'Hemd', variation: 'SS', farbe: 'Weiß', groesse: 'M', bestand: 5 },
  { id: 3, geschlecht: 'Herren', produkt: 'Hose', variation: '-', farbe: 'Schwarz', groesse: '50', bestand: 3 },
  { id: 4, geschlecht: 'Unisex', produkt: 'Jacke', variation: '-', farbe: 'Blau', groesse: 'L', bestand: 2 },
];

export default function Home() {
  const [daten, setDaten] = useState(startDaten);
  const [suche, setSuche] = useState('');

  const gefiltert = useMemo(() => {
    const s = suche.trim().toLowerCase();
    if (!s) return daten;

    return daten.filter((x) =>
      [x.geschlecht, x.produkt, x.variation, x.farbe, x.groesse]
        .join(' ')
        .toLowerCase()
        .includes(s)
    );
  }, [daten, suche]);

  function bestandAendern(id, wert) {
    setDaten((alt) =>
      alt.map((x) =>
        x.id === id
          ? { ...x, bestand: Math.max(0, x.bestand + wert) }
          : x
      )
    );
  }

  return (
    <main className="seite">
      <div className="kopf">
        <h1>Uniformlager</h1>
        <p>Mobiler Überblick für Mitarbeiteruniformen</p>
      </div>

      <input
        className="suche"
        value={suche}
        onChange={(e) => setSuche(e.target.value)}
        placeholder="Suchen: Hemd, Damen, Größe, Farbe ..."
      />

      <div className="liste">
        {gefiltert.map((x) => (
          <div className="karte" key={x.id}>
            <div className="zeileOben">
              <div>
                <h2>{x.produkt}</h2>
                <p>{x.geschlecht} · {x.variation} · {x.farbe} · Größe {x.groesse}</p>
              </div>
              <div className={x.bestand <= 2 ? 'bestand warnung' : 'bestand'}>
                {x.bestand}
              </div>
            </div>

            <div className="buttons">
              <button onClick={() => bestandAendern(x.id, -1)}>- Abgang</button>
              <button onClick={() => bestandAendern(x.id, 1)}>+ Zugang</button>
            </div>
          </div>
        ))}
      </div>
    </main>
  );
}
